# Image Proccessing Api
Image Proccessing API allows you to serve your website faster with no multiple copies of your images!

## Endpoints
Send GET Requests with this params


## GuideLines 

### Build TS
npm run build

### Serve App
npm run serve

### Run tests
npm run test

### Eslint
npm run lint

### Pretify Code
npm run prettier

## Access Edited pic 
to show edited pic you should go to http://localhost:4000/api/convert?filename=icelandwaterfall.jpg(filename)
&width=500(width)&height=500(height)
