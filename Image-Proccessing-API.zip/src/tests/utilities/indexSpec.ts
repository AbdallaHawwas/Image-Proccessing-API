import path from "path";
import { resize } from "./../../utilities";

describe("Test resize function", () => {
    it("should be valid", () => {
        expect(resize(path.resolve('./../../../assets/fjord.jpg'), {width: 300, height: 300})).toBeTruthy();
    });
});
