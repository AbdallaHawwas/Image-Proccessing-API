import { NextFunction, Request, Response } from 'express'
import { getImagePath } from './../utilities/'
import { existsSync } from 'fs'

const validateParams = (req: Request, res: Response, next: NextFunction) => {
  const { width, height, filename } = req.query
  if (
    !Number(width) ||
    !Number(height) ||
    !existsSync(getImagePath(filename as string))
  ) {
    res.status(404).json({
      code: 404,
      message: 'Bad request',
    })
  } else {
    next()
  }
}

export { validateParams }
